// iLovePDF Help - Main Application Script
// Commercial-grade document converter platform

document.addEventListener('DOMContentLoaded', function() {
    // State Management
    const state = {
        currentTool: null,
        uploadedFiles: [],
        toolSettings: {},
        workflowSteps: [],
        isProcessing: false,
        currentProgress: 0,
        darkMode: localStorage.getItem('darkMode') === 'true'
    };

    // Initialize theme
    if (state.darkMode) {
        document.documentElement.setAttribute('data-theme', 'dark');
    }

    // Tools Database
    const tools = [
        // Organize PDF
        { id: 'merge', name: 'Merge PDF', icon: 'fa-object-group', category: 'organize', 
          description: 'Combine PDFs in the order you want', color: '#ff4757' },
        { id: 'split', name: 'Split PDF', icon: 'fa-cut', category: 'organize', 
          description: 'Separate pages into multiple PDFs', color: '#3742fa' },
        { id: 'compress', name: 'Compress PDF', icon: 'fa-compress-alt', category: 'optimize', 
          description: 'Reduce file size while keeping quality', color: '#2ed573' },
        { id: 'organize', name: 'Organize PDF', icon: 'fa-layer-group', category: 'organize', 
          description: 'Rearrange, delete, or rotate pages', color: '#ffa502' },
        { id: 'crop', name: 'Crop PDF', icon: 'fa-crop-alt', category: 'edit', 
          description: 'Crop margins and adjust page size', color: '#a55eea' },
        { id: 'rotate', name: 'Rotate PDF', icon: 'fa-redo-alt', category: 'organize', 
          description: 'Rotate PDF pages clockwise or counterclockwise', color: '#1e90ff' },
        { id: 'page-numbers', name: 'Page Numbers', icon: 'fa-sort-numeric-up', category: 'edit', 
          description: 'Add page numbers to PDF documents', color: '#ff7f50' },
        
        // Convert PDF
        { id: 'pdf-to-word', name: 'PDF to Word', icon: 'fa-file-word', category: 'convert', 
          description: 'Convert PDF to editable Word documents', color: '#2b579a' },
        { id: 'pdf-to-ppt', name: 'PDF to PowerPoint', icon: 'fa-file-powerpoint', category: 'convert', 
          description: 'Convert PDF to PowerPoint presentations', color: '#d24726' },
        { id: 'pdf-to-excel', name: 'PDF to Excel', icon: 'fa-file-excel', category: 'convert', 
          description: 'Extract data from PDF to Excel', color: '#217346' },
        { id: 'pdf-to-jpg', name: 'PDF to JPG', icon: 'fa-file-image', category: 'convert', 
          description: 'Convert PDF pages to JPG images', color: '#ff6b81' },
        { id: 'pdf-to-pdfa', name: 'PDF to PDF/A', icon: 'fa-file-contract', category: 'convert', 
          description: 'Convert PDF to PDF/A format for archiving', color: '#70a1ff' },
        { id: 'html-to-pdf', name: 'HTML to PDF', icon: 'fa-code', category: 'convert', 
          description: 'Convert HTML web pages to PDF', color: '#eccc68' },
        
        // To PDF
        { id: 'word-to-pdf', name: 'Word to PDF', icon: 'fa-file-pdf', category: 'convert', 
          description: 'Convert Word documents to PDF', color: '#ff4757' },
        { id: 'ppt-to-pdf', name: 'PowerPoint to PDF', icon: 'fa-file-pdf', category: 'convert', 
          description: 'Convert PowerPoint to PDF', color: '#ff4757' },
        { id: 'excel-to-pdf', name: 'Excel to PDF', icon: 'fa-file-pdf', category: 'convert', 
          description: 'Convert Excel spreadsheets to PDF', color: '#ff4757' },
        { id: 'jpg-to-pdf', name: 'JPG to PDF', icon: 'fa-file-pdf', category: 'convert', 
          description: 'Convert JPG images to PDF', color: '#ff4757' },
        { id: 'scan-to-pdf', name: 'Scan to PDF', icon: 'fa-scanner', category: 'convert', 
          description: 'Convert scanned documents to PDF', color: '#7bed9f' },
        
        // Edit PDF
        { id: 'edit-pdf', name: 'Edit PDF', icon: 'fa-edit', category: 'edit', 
          description: 'Add text, images, shapes to PDF', color: '#ffa502' },
        { id: 'ocr', name: 'OCR PDF', icon: 'fa-eye', category: 'edit', 
          description: 'Convert scanned PDF to searchable text', color: '#2ed573' },
        { id: 'watermark', name: 'Watermark PDF', icon: 'fa-tint', category: 'security', 
          description: 'Add text or image watermark', color: '#70a1ff' },
        { id: 'redact', name: 'Redact PDF', icon: 'fa-marker', category: 'security', 
          description: 'Permanently remove sensitive information', color: '#ff4757' },
        { id: 'compare', name: 'Compare PDF', icon: 'fa-balance-scale', category: 'edit', 
          description: 'Compare two PDF files and highlight differences', color: '#a55eea' },
        { id: 'repair', name: 'Repair PDF', icon: 'fa-tools', category: 'optimize', 
          description: 'Repair corrupted or damaged PDF files', color: '#ff7f50' },
        
        // PDF Security
        { id: 'protect', name: 'Protect PDF', icon: 'fa-lock', category: 'security', 
          description: 'Add password protection to PDF', color: '#2ed573' },
        { id: 'unlock', name: 'Unlock PDF', icon: 'fa-unlock', category: 'security', 
          description: 'Remove password from PDF', color: '#ff6b81' },
        { id: 'sign', name: 'Sign PDF', icon: 'fa-signature', category: 'security', 
          description: 'Digitally sign PDF documents', color: '#3742fa' },
        
        // Workflow
        { id: 'workflow', name: 'Create Workflow', icon: 'fa-stream', category: 'organize', 
          description: 'Create automated PDF workflows', color: '#eccc68' }
    ];

    // DOM Elements
    const toolsGrid = document.getElementById('toolsGrid');
    const toolInterface = document.getElementById('toolInterface');
    const categoryButtons = document.querySelectorAll('.category-btn');
    const modalContainer = document.getElementById('modalContainer');
    const modalBody = document.getElementById('modalBody');
    const modalClose = document.querySelector('.modal-close');
    const toastContainer = document.getElementById('toastContainer');
    const darkModeBtn = document.querySelector('.btn-dark-mode');
    const menuBtn = document.querySelector('.btn-menu');
    const mainNav = document.querySelector('.main-nav');

    // Initialize Application
    function init() {
        loadTools();
        setupEventListeners();
        loadWorkflowFromStorage();
    }

    // Load Tools Grid
    function loadTools(filter = 'all') {
        toolsGrid.innerHTML = '';
        
        const filteredTools = filter === 'all' 
            ? tools 
            : tools.filter(tool => tool.category === filter);
        
        filteredTools.forEach(tool => {
            const toolCard = createToolCard(tool);
            toolsGrid.appendChild(toolCard);
        });
    }

    // Create Tool Card Element
    function createToolCard(tool) {
        const card = document.createElement('div');
        card.className = 'tool-card';
        card.dataset.id = tool.id;
        card.dataset.category = tool.category;
        
        card.innerHTML = `
            <div class="tool-icon" style="background: linear-gradient(135deg, ${tool.color}, ${tool.color}dd)">
                <i class="fas ${tool.icon}"></i>
            </div>
            <h3>${tool.name}</h3>
            <p>${tool.description}</p>
            <div class="tool-tags">
                <span class="tool-tag">${getCategoryLabel(tool.category)}</span>
                <span class="tool-tag">FREE</span>
            </div>
        `;
        
        card.addEventListener('click', () => selectTool(tool));
        return card;
    }

    // Get Category Label
    function getCategoryLabel(category) {
        const labels = {
            organize: 'Organize',
            optimize: 'Optimize',
            convert: 'Convert',
            edit: 'Edit',
            security: 'Security'
        };
        return labels[category] || category;
    }

    // Select Tool
    function selectTool(tool) {
        state.currentTool = tool;
        updateUIForTool(tool);
        
        // Show tool interface
        const toolUI = createToolInterface(tool);
        toolInterface.innerHTML = '';
        toolInterface.appendChild(toolUI);
        
        // Scroll to tool interface
        toolInterface.scrollIntoView({ behavior: 'smooth' });
        
        // Show notification
        showToast(`Ready to ${tool.name.toLowerCase()}`, 'success');
    }

    // Create Tool Interface
    function createToolInterface(tool) {
        const container = document.createElement('div');
        container.className = 'tool-interface';
        
        let toolSpecificUI = '';
        
        switch(tool.id) {
            case 'merge':
                toolSpecificUI = createMergeUI();
                break;
            case 'split':
                toolSpecificUI = createSplitUI();
                break;
            case 'compress':
                toolSpecificUI = createCompressUI();
                break;
            case 'edit-pdf':
                toolSpecificUI = createEditUI();
                break;
            case 'workflow':
                toolSpecificUI = createWorkflowUI();
                break;
            default:
                toolSpecificUI = createDefaultToolUI(tool);
        }
        
        container.innerHTML = `
            <div class="tool-header">
                <h2>
                    <i class="fas ${tool.icon}"></i>
                    ${tool.name}
                </h2>
                <button class="btn-secondary" onclick="window.app.resetTool()">
                    <i class="fas fa-redo"></i> Reset
                </button>
            </div>
            ${toolSpecificUI}
        `;
        
        // Attach event listeners after creating UI
        setTimeout(() => {
            const uploadArea = container.querySelector('.upload-area');
            const fileInput = container.querySelector('input[type="file"]');
            
            if (uploadArea && fileInput) {
                setupFileUpload(uploadArea, fileInput);
            }
            
            // Setup tool-specific event listeners
            setupToolSpecificListeners(container, tool.id);
        }, 0);
        
        return container;
    }

    // Create Merge PDF UI
    function createMergeUI() {
        return `
            <div class="upload-area" id="uploadArea">
                <div class="upload-icon">
                    <i class="fas fa-cloud-upload-alt"></i>
                </div>
                <h3>Select PDF files to merge</h3>
                <p>Drag & drop PDF files here or click to browse</p>
                <input type="file" id="fileInput" accept=".pdf" multiple style="display: none;">
                <button class="btn-primary" onclick="document.getElementById('fileInput').click()">
                    <i class="fas fa-plus"></i> Select Files
                </button>
                <p class="file-size-info">Maximum file size: 50MB each</p>
            </div>
            
            <div class="file-list" id="fileList">
                <!-- Files will be listed here -->
            </div>
            
            <div class="tool-settings">
                <div class="settings-group">
                    <h4>Merge Order</h4>
                    <div class="radio-group">
                        <label class="radio-label">
                            <input type="radio" name="mergeOrder" value="alphabetical" checked>
                            <span>Alphabetical order</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="mergeOrder" value="upload">
                            <span>Upload order</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="mergeOrder" value="custom">
                            <span>Custom order (drag to reorder)</span>
                        </label>
                    </div>
                </div>
            </div>
            
            <div class="progress-container" style="display: none;" id="progressContainer">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
                <div class="progress-text">
                    <span>Processing...</span>
                    <span id="progressPercent">0%</span>
                </div>
            </div>
            
            <div class="tool-actions">
                <button class="btn-primary" onclick="window.app.processTool('merge')" id="processBtn">
                    <i class="fas fa-magic"></i> Merge PDFs
                </button>
                <button class="btn-secondary" onclick="window.app.downloadResult()" style="display: none;" id="downloadBtn">
                    <i class="fas fa-download"></i> Download Merged PDF
                </button>
            </div>
        `;
    }

    // Create Split PDF UI
    function createSplitUI() {
        return `
            <div class="upload-area" id="uploadArea">
                <div class="upload-icon">
                    <i class="fas fa-cut"></i>
                </div>
                <h3>Select PDF file to split</h3>
                <p>Drag & drop a PDF file here or click to browse</p>
                <input type="file" id="fileInput" accept=".pdf" style="display: none;">
                <button class="btn-primary" onclick="document.getElementById('fileInput').click()">
                    <i class="fas fa-plus"></i> Select File
                </button>
            </div>
            
            <div class="file-list" id="fileList"></div>
            
            <div class="tool-settings">
                <div class="settings-group">
                    <h4>Split Method</h4>
                    <div class="radio-group">
                        <label class="radio-label">
                            <input type="radio" name="splitMethod" value="ranges" checked>
                            <span>Split by page ranges (e.g., 1-3, 4-5)</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="splitMethod" value="every">
                            <span>Split every N pages</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="splitMethod" value="single">
                            <span>Extract single pages</span>
                        </label>
                    </div>
                </div>
                
                <div class="settings-group" id="rangeSettings">
                    <h4>Page Ranges</h4>
                    <input type="text" class="range-input" 
                           placeholder="e.g., 1-3, 5, 7-9" 
                           style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: var(--radius-sm);">
                    <p class="range-hint">Enter page ranges separated by commas</p>
                </div>
            </div>
            
            <div class="progress-container" style="display: none;" id="progressContainer"></div>
            
            <div class="tool-actions">
                <button class="btn-primary" onclick="window.app.processTool('split')">
                    <i class="fas fa-cut"></i> Split PDF
                </button>
            </div>
        `;
    }

    // Create Compress PDF UI
    function createCompressUI() {
        return `
            <div class="upload-area" id="uploadArea">
                <div class="upload-icon">
                    <i class="fas fa-compress-alt"></i>
                </div>
                <h3>Select PDF file to compress</h3>
                <p>Drag & drop a PDF file here or click to browse</p>
                <input type="file" id="fileInput" accept=".pdf" style="display: none;">
                <button class="btn-primary" onclick="document.getElementById('fileInput').click()">
                    <i class="fas fa-plus"></i> Select File
                </button>
            </div>
            
            <div class="file-list" id="fileList"></div>
            
            <div class="tool-settings">
                <div class="settings-group">
                    <h4>Compression Level</h4>
                    <div class="range-group">
                        <input type="range" min="1" max="3" value="2" class="compression-slider" 
                               style="width: 100%; margin: 15px 0;">
                        <div class="range-value">
                            <span id="compressionLabel">Balanced Compression</span>
                        </div>
                    </div>
                    <div class="compression-options" style="display: flex; justify-content: space-between; margin-top: 20px;">
                        <div class="option">
                            <strong>Low</strong>
                            <p>Small size reduction<br>Best quality</p>
                        </div>
                        <div class="option" style="text-align: center;">
                            <strong>Balanced</strong>
                            <p>Good balance<br>Recommended</p>
                        </div>
                        <div class="option" style="text-align: right;">
                            <strong>High</strong>
                            <p>Maximum compression<br>Smaller file size</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="progress-container" style="display: none;" id="progressContainer"></div>
            
            <div class="tool-actions">
                <button class="btn-primary" onclick="window.app.processTool('compress')">
                    <i class="fas fa-compress-alt"></i> Compress PDF
                </button>
            </div>
        `;
    }

    // Create Edit PDF UI
    function createEditUI() {
        return `
            <div class="upload-area" id="uploadArea">
                <div class="upload-icon">
                    <i class="fas fa-edit"></i>
                </div>
                <h3>Select PDF file to edit</h3>
                <p>Drag & drop a PDF file here or click to browse</p>
                <input type="file" id="fileInput" accept=".pdf" style="display: none;">
                <button class="btn-primary" onclick="document.getElementById('fileInput').click()">
                    <i class="fas fa-plus"></i> Select File
                </button>
            </div>
            
            <div class="pdf-editor" id="pdfEditor" style="display: none;">
                <div class="editor-sidebar">
                    <div class="editor-tools">
                        <button class="editor-tool-btn active" data-tool="select">
                            <i class="fas fa-mouse-pointer"></i>
                            <span>Select</span>
                        </button>
                        <button class="editor-tool-btn" data-tool="text">
                            <i class="fas fa-font"></i>
                            <span>Text</span>
                        </button>
                        <button class="editor-tool-btn" data-tool="image">
                            <i class="fas fa-image"></i>
                            <span>Image</span>
                        </button>
                        <button class="editor-tool-btn" data-tool="draw">
                            <i class="fas fa-pencil-alt"></i>
                            <span>Draw</span>
                        </button>
                        <button class="editor-tool-btn" data-tool="highlight">
                            <i class="fas fa-highlighter"></i>
                            <span>Highlight</span>
                        </button>
                        <button class="editor-tool-btn" data-tool="shape">
                            <i class="fas fa-square"></i>
                            <span>Shapes</span>
                        </button>
                        <button class="editor-tool-btn" data-tool="sign">
                            <i class="fas fa-signature"></i>
                            <span>Signature</span>
                        </button>
                    </div>
                    
                    <div class="editor-properties" style="margin-top: 30px;">
                        <h4 style="margin-bottom: 15px;">Properties</h4>
                        <div class="property-group">
                            <label>Color</label>
                            <input type="color" value="#ff4757" style="width: 100%;">
                        </div>
                        <div class="property-group">
                            <label>Font Size</label>
                            <input type="range" min="8" max="72" value="16" style="width: 100%;">
                        </div>
                    </div>
                </div>
                <div class="editor-main">
                    <div class="editor-controls">
                        <button class="btn-icon" title="Zoom Out">
                            <i class="fas fa-search-minus"></i>
                        </button>
                        <span class="zoom-level">100%</span>
                        <button class="btn-icon" title="Zoom In">
                            <i class="fas fa-search-plus"></i>
                        </button>
                        <button class="btn-icon" title="Previous Page">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                        <span>Page <span id="currentPage">1</span> of <span id="totalPages">1</span></span>
                        <button class="btn-icon" title="Next Page">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                    <canvas class="editor-canvas" id="pdfCanvas"></canvas>
                </div>
            </div>
            
            <div class="tool-actions">
                <button class="btn-primary" onclick="window.app.processTool('edit')" id="processEditBtn">
                    <i class="fas fa-save"></i> Save Edits
                </button>
            </div>
        `;
    }

    // Create Workflow UI
    function createWorkflowUI() {
        return `
            <div class="workflow-builder">
                <h3 style="margin-bottom: 20px;"><i class="fas fa-stream"></i> Create Automated Workflow</h3>
                <p style="margin-bottom: 30px; color: var(--text-secondary);">
                    Build automated workflows by combining multiple PDF tools. Drag and drop tools to create your sequence.
                </p>
                
                <div class="available-tools">
                    <h4 style="margin-bottom: 15px;">Available Tools</h4>
                    <div class="tools-selection" style="display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 30px;">
                        ${getWorkflowTools()}
                    </div>
                </div>
                
                <div class="workflow-container">
                    <h4 style="margin-bottom: 15px;">Your Workflow</h4>
                    <div class="workflow-steps" id="workflowSteps">
                        <!-- Workflow steps will appear here -->
                        ${state.workflowSteps.length === 0 ? 
                            '<p style="text-align: center; color: var(--text-light); padding: 40px;">Drag tools here to build your workflow</p>' : 
                            state.workflowSteps.map(step => createWorkflowStepHTML(step)).join('')
                        }
                    </div>
                </div>
                
                <div class="workflow-actions" style="display: flex; gap: 15px; margin-top: 30px;">
                    <button class="btn-primary" onclick="window.app.saveWorkflow()">
                        <i class="fas fa-save"></i> Save Workflow
                    </button>
                    <button class="btn-secondary" onclick="window.app.runWorkflow()">
                        <i class="fas fa-play"></i> Run Workflow
                    </button>
                    <button class="btn-secondary" onclick="window.app.clearWorkflow()">
                        <i class="fas fa-trash"></i> Clear
                    </button>
                </div>
            </div>
        `;
    }

    // Create Default Tool UI
    function createDefaultToolUI(tool) {
        return `
            <div class="upload-area" id="uploadArea">
                <div class="upload-icon">
                    <i class="fas ${tool.icon}"></i>
                </div>
                <h3>Select files for ${tool.name}</h3>
                <p>Drag & drop files here or click to browse</p>
                <input type="file" id="fileInput" accept="${getFileAccept(tool.id)}" multiple style="display: none;">
                <button class="btn-primary" onclick="document.getElementById('fileInput').click()">
                    <i class="fas fa-plus"></i> Select Files
                </button>
            </div>
            
            <div class="file-list" id="fileList"></div>
            
            <div class="tool-settings">
                ${getToolSpecificSettings(tool.id)}
            </div>
            
            <div class="progress-container" style="display: none;" id="progressContainer"></div>
            
            <div class="tool-actions">
                <button class="btn-primary" onclick="window.app.processTool('${tool.id}')">
                    <i class="fas fa-magic"></i> Process
                </button>
            </div>
        `;
    }

    // File Upload Setup
    function setupFileUpload(uploadArea, fileInput) {
        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('drag-over');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('drag-over');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('drag-over');
            
            const files = Array.from(e.dataTransfer.files);
            handleFiles(files);
        });
        
        // File input change
        fileInput.addEventListener('change', (e) => {
            const files = Array.from(e.target.files);
            handleFiles(files);
        });
    }

    // Handle Uploaded Files
    function handleFiles(files) {
        files.forEach(file => {
            // Validate file
            if (!validateFile(file)) {
                showToast(`Invalid file: ${file.name}`, 'error');
                return;
            }
            
            // Add to state
            state.uploadedFiles.push({
                id: Date.now() + Math.random(),
                file: file,
                name: file.name,
                size: formatFileSize(file.size),
                type: file.type,
                progress: 0
            });
        });
        
        updateFileList();
        showToast(`${files.length} file(s) added`, 'success');
    }

    // Validate File
    function validateFile(file) {
        const maxSize = 50 * 1024 * 1024; // 50MB
        const acceptedTypes = ['application/pdf', 'image/jpeg', 'image/png', 
                              'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                              'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                              'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
        
        if (file.size > maxSize) {
            return false;
        }
        
        if (!acceptedTypes.includes(file.type) && !file.name.match(/\.(pdf|doc|docx|ppt|pptx|xls|xlsx|jpg|jpeg|png)$/i)) {
            return false;
        }
        
        return true;
    }

    // Update File List UI
    function updateFileList() {
        const fileList = document.getElementById('fileList');
        if (!fileList) return;
        
        if (state.uploadedFiles.length === 0) {
            fileList.innerHTML = '';
            return;
        }
        
        fileList.innerHTML = state.uploadedFiles.map(file => `
            <div class="file-item" data-id="${file.id}">
                <div class="file-info">
                    <div class="file-icon">
                        <i class="fas ${getFileIcon(file.type)}"></i>
                    </div>
                    <div class="file-details">
                        <h4>${file.name}</h4>
                        <p>${file.size}</p>
                    </div>
                </div>
                <div class="file-actions">
                    <button class="btn-icon" onclick="window.app.removeFile('${file.id}')" title="Remove">
                        <i class="fas fa-times"></i>
                    </button>
                    <button class="btn-icon" onclick="window.app.previewFile('${file.id}')" title="Preview">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    // Process Tool
    function processTool(toolId) {
        if (state.uploadedFiles.length === 0) {
            showToast('Please upload files first', 'warning');
            return;
        }
        
        state.isProcessing = true;
        state.currentProgress = 0;
        
        // Show progress bar
        const progressContainer = document.getElementById('progressContainer');
        const progressFill = document.getElementById('progressFill');
        const progressPercent = document.getElementById('progressPercent');
        
        if (progressContainer) {
            progressContainer.style.display = 'block';
        }
        
        // Simulate processing
        const interval = setInterval(() => {
            state.currentProgress += Math.random() * 10;
            
            if (state.currentProgress >= 100) {
                state.currentProgress = 100;
                clearInterval(interval);
                processingComplete(toolId);
            }
            
            if (progressFill) {
                progressFill.style.width = state.currentProgress + '%';
            }
            
            if (progressPercent) {
                progressPercent.textContent = Math.round(state.currentProgress) + '%';
            }
        }, 200);
    }

    // Processing Complete
    function processingComplete(toolId) {
        state.isProcessing = false;
        
        // Show success message
        showToast(`${state.currentTool.name} completed successfully!`, 'success');
        
        // Show download button
        const processBtn = document.getElementById('processBtn');
        const downloadBtn = document.getElementById('downloadBtn');
        
        if (processBtn && downloadBtn) {
            processBtn.style.display = 'none';
            downloadBtn.style.display = 'inline-flex';
        }
        
        // Reset progress bar
        setTimeout(() => {
            const progressContainer = document.getElementById('progressContainer');
            if (progressContainer) {
                progressContainer.style.display = 'none';
            }
        }, 2000);
    }

    // Download Result
    function downloadResult() {
        // Create a mock download
        const fileName = `processed-${Date.now()}.pdf`;
        const content = "This is a mock download. In a real application, this would be the processed file.";
        const blob = new Blob([content], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        showToast('File downloaded successfully', 'success');
    }

    // Show Toast Notification
    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <i class="fas ${getToastIcon(type)}"></i>
            <span>${message}</span>
        `;
        
        toastContainer.appendChild(toast);
        
        // Show toast
        setTimeout(() => toast.classList.add('show'), 100);
        
        // Remove toast after 4 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    // Helper Functions
    function getFileIcon(fileType) {
        if (fileType.includes('pdf')) return 'fa-file-pdf';
        if (fileType.includes('word')) return 'fa-file-word';
        if (fileType.includes('powerpoint')) return 'fa-file-powerpoint';
        if (fileType.includes('excel')) return 'fa-file-excel';
        if (fileType.includes('image')) return 'fa-file-image';
        return 'fa-file';
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function getToastIcon(type) {
        switch(type) {
            case 'success': return 'fa-check-circle';
            case 'error': return 'fa-exclamation-circle';
            case 'warning': return 'fa-exclamation-triangle';
            default: return 'fa-info-circle';
        }
    }

    function getFileAccept(toolId) {
        const acceptMap = {
            'merge': '.pdf',
            'split': '.pdf',
            'compress': '.pdf',
            'pdf-to-word': '.pdf',
            'pdf-to-ppt': '.pdf',
            'pdf-to-excel': '.pdf',
            'pdf-to-jpg': '.pdf',
            'word-to-pdf': '.doc,.docx',
            'ppt-to-pdf': '.ppt,.pptx',
            'excel-to-pdf': '.xls,.xlsx',
            'jpg-to-pdf': '.jpg,.jpeg,.png',
            'edit-pdf': '.pdf'
        };
        return acceptMap[toolId] || '*';
    }

    function getToolSpecificSettings(toolId) {
        const settings = {
            'watermark': `
                <div class="settings-group">
                    <h4>Watermark Type</h4>
                    <div class="radio-group">
                        <label class="radio-label">
                            <input type="radio" name="watermarkType" value="text" checked>
                            <span>Text Watermark</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="watermarkType" value="image">
                            <span>Image Watermark</span>
                        </label>
                    </div>
                </div>
            `,
            'protect': `
                <div class="settings-group">
                    <h4>Password Protection</h4>
                    <input type="password" placeholder="Enter password" style="width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid var(--border-color); border-radius: var(--radius-sm);">
                    <input type="password" placeholder="Confirm password" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: var(--radius-sm);">
                </div>
            `
        };
        return settings[toolId] || '<p>No additional settings required for this tool.</p>';
    }

    function getWorkflowTools() {
        return tools.slice(0, 8).map(tool => `
            <div class="workflow-step" draggable="true" data-tool="${tool.id}" style="cursor: move; padding: 10px 15px; background: var(--card-bg); border-radius: var(--radius-sm); border: 1px solid var(--border-color);">
                <i class="fas ${tool.icon}"></i>
                <span>${tool.name}</span>
            </div>
        `).join('');
    }

    function createWorkflowStepHTML(step) {
        const tool = tools.find(t => t.id === step.toolId);
        if (!tool) return '';
        
        return `
            <div class="workflow-step" data-step="${step.id}">
                <div class="step-handle">
                    <i class="fas fa-grip-vertical"></i>
                </div>
                <div class="step-icon" style="color: ${tool.color};">
                    <i class="fas ${tool.icon}"></i>
                </div>
                <div class="step-details">
                    <strong>${tool.name}</strong>
                    <small>${tool.description}</small>
                </div>
                <button class="btn-icon" onclick="window.app.removeWorkflowStep('${step.id}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
    }

    // Setup Event Listeners
    function setupEventListeners() {
        // Category filter buttons
        categoryButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                categoryButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                loadTools(btn.dataset.category);
            });
        });
        
        // Dark mode toggle
        darkModeBtn.addEventListener('click', toggleDarkMode);
        
        // Mobile menu toggle
        menuBtn.addEventListener('click', () => {
            mainNav.classList.toggle('active');
        });
        
        // Modal close
        modalClose.addEventListener('click', () => {
            modalContainer.classList.remove('active');
        });
        
        // Close modal on background click
        modalContainer.addEventListener('click', (e) => {
            if (e.target === modalContainer) {
                modalContainer.classList.remove('active');
            }
        });
        
        // Setup workflow drag and drop
        setupWorkflowDragDrop();
    }

    function setupWorkflowDragDrop() {
        const workflowSteps = document.getElementById('workflowSteps');
        if (!workflowSteps) return;
        
        workflowSteps.addEventListener('dragover', (e) => {
            e.preventDefault();
        });
        
        workflowSteps.addEventListener('drop', (e) => {
            e.preventDefault();
            const toolId = e.dataTransfer.getData('text/plain');
            if (toolId) {
                addWorkflowStep(toolId);
            }
        });
    }

    function addWorkflowStep(toolId) {
        const step = {
            id: Date.now().toString(),
            toolId: toolId,
            order: state.workflowSteps.length + 1
        };
        
        state.workflowSteps.push(step);
        saveWorkflowToStorage();
        
        // Update UI
        const workflowUI = document.querySelector('.workflow-builder');
        if (workflowUI) {
            workflowUI.innerHTML = createWorkflowUI();
            setupWorkflowDragDrop();
        }
        
        showToast('Tool added to workflow', 'success');
    }

    function saveWorkflowToStorage() {
        localStorage.setItem('pdfWorkflow', JSON.stringify(state.workflowSteps));
    }

    function loadWorkflowFromStorage() {
        const saved = localStorage.getItem('pdfWorkflow');
        if (saved) {
            state.workflowSteps = JSON.parse(saved);
        }
    }

    function toggleDarkMode() {
        state.darkMode = !state.darkMode;
        
        if (state.darkMode) {
            document.documentElement.setAttribute('data-theme', 'dark');
            darkModeBtn.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
            document.documentElement.removeAttribute('data-theme');
            darkModeBtn.innerHTML = '<i class="fas fa-moon"></i>';
        }
        
        localStorage.setItem('darkMode', state.darkMode);
        showToast(`Dark mode ${state.darkMode ? 'enabled' : 'disabled'}`, 'info');
    }

    function setupToolSpecificListeners(container, toolId) {
        // Add tool-specific listeners here
        switch(toolId) {
            case 'compress':
                const slider = container.querySelector('.compression-slider');
                const label = container.querySelector('#compressionLabel');
                if (slider && label) {
                    slider.addEventListener('input', (e) => {
                        const value = parseInt(e.target.value);
                        const labels = ['Low Compression', 'Balanced Compression', 'High Compression'];
                        label.textContent = labels[value - 1];
                    });
                }
                break;
        }
    }

    // Update UI for selected tool
    function updateUIForTool(tool) {
        // Update active nav link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${tool.category}`) {
                link.classList.add('active');
            }
        });
        
        // Update category buttons
        document.querySelectorAll('.category-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.category === tool.category) {
                btn.classList.add('active');
            }
        });
        
        // Load tools in same category
        loadTools(tool.category);
    }

    // Public API for inline onclick handlers
    window.app = {
        resetTool: () => {
            state.uploadedFiles = [];
            updateFileList();
            showToast('Tool reset', 'info');
        },
        
        removeFile: (fileId) => {
            state.uploadedFiles = state.uploadedFiles.filter(f => f.id !== fileId);
            updateFileList();
            showToast('File removed', 'info');
        },
        
        previewFile: (fileId) => {
            showToast('Preview feature would open here', 'info');
        },
        
        processTool: (toolId) => {
            processTool(toolId);
        },
        
        downloadResult: () => {
            downloadResult();
        },
        
        saveWorkflow: () => {
            saveWorkflowToStorage();
            showToast('Workflow saved locally', 'success');
        },
        
        runWorkflow: () => {
            if (state.workflowSteps.length === 0) {
                showToast('Please add tools to your workflow first', 'warning');
                return;
            }
            showToast('Running workflow...', 'info');
            // In a real app, this would process each step sequentially
        },
        
        clearWorkflow: () => {
            state.workflowSteps = [];
            saveWorkflowToStorage();
            
            const workflowUI = document.querySelector('.workflow-builder');
            if (workflowUI) {
                workflowUI.innerHTML = createWorkflowUI();
                setupWorkflowDragDrop();
            }
            
            showToast('Workflow cleared', 'info');
        },
        
        removeWorkflowStep: (stepId) => {
            state.workflowSteps = state.workflowSteps.filter(s => s.id !== stepId);
            saveWorkflowToStorage();
            
            const workflowUI = document.querySelector('.workflow-builder');
            if (workflowUI) {
                workflowUI.innerHTML = createWorkflowUI();
                setupWorkflowDragDrop();
            }
            
            showToast('Step removed from workflow', 'info');
        }
    };

    // Initialize the app
    init();
});